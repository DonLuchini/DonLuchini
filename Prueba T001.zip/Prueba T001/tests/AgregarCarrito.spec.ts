import { test, expect } from '@playwright/test';

test ('Acceso pagina y Seleccion de producto', async ({ page }) => {
    await page.goto('https://opencart.abstracta.us/')
  
    // Se debe abrir la página con el título Your Store
    await expect(page).toHaveTitle(/Your Store/)
  
    //En la sección "Desktops" seleccionar submenú "Show All Desktop"
    await page.getByRole('link', { name: 'Desktops'}).click();
    await page.getByRole('link', { name: 'Show All Desktops' }).click();
    
    //Seleccionar y agregar a carrito producto "Apple Cinema 30"
    await page.getByText('Apple Cinema 30"').click();

    // Se debe abrir una nueva pagina con el detalle del producto y una sección llamada "Avialable Options"
    await expect(page.getByRole('heading', { name: 'Available Options' })).toBeVisible();

    //Seleccionar Check 3 y 4
    await page.getByLabel('Checkbox 3 (+$36.00)').check();
    await page.getByLabel('Checkbox 4 (+$48.00)').check();

    //Completar campo "Text", seleccionar opción "Red", Completar campo "Textarea" 
    await page.getByPlaceholder('Text', { exact: true }).fill('Datamart');
    await page.getByLabel('Select').selectOption('Red (+$4.80)');
    await page.getByPlaceholder('Textarea').fill('Prueba de texto');
    await page.getByLabel('Qty').fill('3');

    //Dar clic en botón "Add to Cart"
    await page.getByRole('button', { name: 'Add to Cart', exact: true }).click();
    
    //Validar que aparezca mensaje "Radio required"
    await expect(page.getByText('Radio required!')).toBeVisible();
    
}) 