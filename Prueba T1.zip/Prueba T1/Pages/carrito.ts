import { Page, expect } from "@playwright/test";
import { HelperBase } from "./helperBase";
import exp from "constants";

export class Carrito extends HelperBase {

    constructor (page: Page){
        super(page)
    }

async obtenerTotalCarrito(){
    const totalCarrito = await this.page.getByRole('cell', { name: '$583.19' }).textContent();
}

async compararTotalCarrito(){
    const total:number = parseFloat('$583.19'?.replace(/[^\d.-]/g, '') || '0');

    await expect(122.00 + 123.20 + 337.99).toBeCloseTo(583.19 , 2)
}
}