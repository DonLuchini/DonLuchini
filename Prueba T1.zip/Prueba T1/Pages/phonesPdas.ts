import { Page, expect } from "@playwright/test";
import { HelperBase } from "./helperBase";

export class PhonesPdas extends HelperBase {

    constructor (page: Page){
        super(page)
    }

async selecionarPhones(){
    await this.page.getByRole('link', { name: 'Phones & PDAs' }).click()

}

async seleccionarPrecios(){
    const precioProducto1 = await this.page.getByText('$122.00 Ex Tax: $').textContent();
    const precioProducto2 = await this.page.getByText('$123.20 Ex Tax: $').textContent();
    const precioProducto3 = await this.page.getByText('$337.99 Ex Tax: $').textContent();

}

async convertirPrecios(){
    const precio1:number = parseFloat('$122.00 Ex Tax: $'?.replace(/[^\d.-]/g, '') || '0');
    const precio2:number = parseFloat('$123.20 Ex Tax: $'?.replace(/[^\d.-]/g, '') || '0');
    const precio3:number = parseFloat('$337.99 Ex Tax: $'?.replace(/[^\d.-]/g, '') || '0');

}

async sumarPrecios(){
    const sumaProductos = 122.00 + 123.20 + 337.99;
}

async agregarCelularUno(){
    await this.page.getByRole('button', { name: ' Add to Cart' }).first().click()

    // Esperamos a que el texto de validación sea visible
    const textoValidacion = this.page.locator('text=Success: You have added HTC Touch HD');

    // Verificamos que el texto sea visible
    await expect(textoValidacion).toBeVisible();

}

async agregarCelularDos(){
    await this.page.getByRole('button', { name: ' Add to Cart' }).nth(1).click()
    
    // Esperamos a que el texto de validación sea visible
    const textoValidacion = this.page.locator('text=Success: You have added iPhone');

    // Verificamos que el texto sea visible
    await expect(textoValidacion).toBeVisible();
}

async agregarCelularTres(){
    await this.page.getByRole('button', { name: ' Add to Cart' }).nth(2).click()
    
    // Esperamos a que el texto de validación sea visible
    const textoValidacion = this.page.locator('text=Success: You have added Palm Treo Pro');

    // Verificamos que el texto sea visible
    await expect(textoValidacion).toBeVisible();
}

async clickEnBotonCarrito(){
    await this.page.getByRole('button', { name: ' 3 item(s) - $' }).click()


}


}