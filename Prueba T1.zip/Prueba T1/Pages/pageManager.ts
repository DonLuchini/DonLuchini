import { Page, BrowserContext} from '@playwright/test'
import { PaginaPrincipal } from './paginaPrincipal'
import { Desktops } from './desktops'
import { PhonesPdas } from './phonesPdas'
import { Carrito } from './carrito'


export class PageManager {
    private readonly page: Page
    private readonly context: BrowserContext

    private readonly paginaPrincipal: PaginaPrincipal
    private readonly desktops: Desktops
    private readonly phonesPdas: PhonesPdas
    private readonly carrito: Carrito


constructor(page: Page, context: BrowserContext){
    this.page = page
    this.paginaPrincipal = new PaginaPrincipal(this.page)
    this.desktops = new Desktops(this.page)
    this.phonesPdas = new PhonesPdas(this.page)
    this.carrito = new Carrito(this.page)


}
onPaginaPrincipal(){
    return this.paginaPrincipal
}

onDesktops(){
    return this.desktops
}

onPhonesPdas(){
    return this.phonesPdas
}

onCarrito(){
    return this.carrito
}
}
