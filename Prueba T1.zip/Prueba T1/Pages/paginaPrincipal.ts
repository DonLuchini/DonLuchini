import { expect, type Locator, type Page } from "@playwright/test";
import { HelperBase } from "./helperBase";

export class PaginaPrincipal extends HelperBase {

    constructor (page: Page){
        super(page)
    }

    async accesoPagina(){
        await this.page.goto('https://opencart.abstracta.us/')

    }


}