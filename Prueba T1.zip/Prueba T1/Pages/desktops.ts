import { Page, expect } from "@playwright/test";
import { HelperBase } from "./helperBase";

export class Desktops extends HelperBase {

    constructor (page: Page){
        super(page)
        
        
        this.page.getByRole('link', {name:'Desktops'})
    }
async accesoDesktop(){
    await this.page.getByRole('link', {name:'Desktops' }).click();
    await this.page.getByRole('link', {name:'Show All Desktops'}).click();

}

async seleccionDesktop(){
    await this.page.getByText('Apple Cinema 30"').click();
    
}

async seleccionCheckbox(){
    await this.page.getByLabel('Checkbox 3 (+$36.00)').check();
    await this.page.getByLabel('Checkbox 4 (+$48.00)').check();
    
}
async ingresoTexto(){
    await this.page.getByPlaceholder('Text', { exact: true }).fill('Probando texto')

}
async elegirColor(){
    await this.page.getByLabel('Select').selectOption('Red (+$4.80)')
}

async ingresoTextarea(){
    await this.page.getByPlaceholder('Textarea').fill('Prueba de texto')
}

async ingresoCantidad(){
    await this.page.getByLabel('Qty').fill('3');
}
// Hacer click en botón Add to Cart y verificar que aparezca mensaje de información requerida

async agregarProductoCarrito(){
    await this.page.getByRole('button', { name: 'Add to Cart', exact: true }).click();

    await expect(this.page.getByText('Radio required!')).toBeVisible()
}

}