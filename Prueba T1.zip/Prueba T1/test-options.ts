import { test as base } from '@playwright/test'
import { PageManager } from './Pages/pageManager'
import Fixture from './fixtures/fixture.json'


export type TestOptions = {
    globalQaURL: string
    formLayoutPage: string
    pageManager: PageManager
    fixture: any
}

export const test = base.extend<TestOptions>({
    // globalQaURL: ['', { option: true }],

    // formLayoutPage: async ({ page }, use) => {
    //     await page.goto('/')
    //     await page.getByText('Forms').click()
    //     await page.getByText('Form Layouts').click()
    //     await use('')
    // },

    pageManager: async ({ page, context }, use) => {
        const pm = new PageManager(page, context)
        await use(pm)
    },

    fixture: async ({ page }, use: any) => {
        await use(Fixture)
    }
})