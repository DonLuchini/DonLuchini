import { test } from "../test-options";


test('Ingreso a pagina y seleccion de producto', async ({pageManager, page}) => {
    await pageManager.onPaginaPrincipal().accesoPagina()
    await pageManager.onDesktops().accesoDesktop()
    await pageManager.onDesktops().seleccionDesktop()
    //Se procede a completar los campos faltantes
    await pageManager.onDesktops().seleccionCheckbox()
    await pageManager.onDesktops().ingresoTexto()
    await pageManager.onDesktops().elegirColor()
    await pageManager.onDesktops().ingresoTextarea()
    await pageManager.onDesktops().ingresoCantidad()
    //Se da clcic en botón "Add to Cart" y se espera resultado
    await pageManager.onDesktops().agregarProductoCarrito()
    
})

