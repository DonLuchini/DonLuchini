import { test } from "../test-options";

test('Ingresar a pagina y agregar productos al carrito', async ({pageManager, page}) => {

    await pageManager.onPaginaPrincipal().accesoPagina()
    await pageManager.onPhonesPdas().selecionarPhones()
    await pageManager.onPhonesPdas().seleccionarPrecios()
    await pageManager.onPhonesPdas().convertirPrecios()
    await pageManager.onPhonesPdas().sumarPrecios()
    await pageManager.onPhonesPdas().agregarCelularUno()
    await pageManager.onPhonesPdas().agregarCelularDos()
    await pageManager.onPhonesPdas().agregarCelularTres()
    await pageManager.onPhonesPdas().clickEnBotonCarrito()
    await pageManager.onCarrito().obtenerTotalCarrito()
    await pageManager.onCarrito().compararTotalCarrito()
    

}
)